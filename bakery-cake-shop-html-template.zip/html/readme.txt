Bakery Cake Shop HTML template is designed for any cake or bakery store. You can use this template as a framework and start building as you require.

The code is consistent and can be easily maintained as we have followed a good coding standards. We want everyone to easily understand it and modify it according to their requirement. As the main goal of providing these templates is to help you with your design project.


FREE FOR BOTH PERSONAL AND COMMERCIAL USE

This HTML Template is provided by templatesjungle.com and is free to use in 
both personal and commercial projects.


RIGHTS

You are allowed to use it in your personal projects and commercial projects.

You can modify and use it as a part of your big projects.

Credit is not required but it will be very appreciated if you can somehow link us back. You can simply mention templatesjungle.com somewhere in your website.


PROHIBITIONS

You are not permitted to resell or redistribute (paid or free) as it is. 

Even if you want to share the free resource in your blog, you must point it to original Templates Jungle resource page. 

You cannot host the download file in your website.


SUPPORT

You can contact us to report any bugs and errors in the template. We will try and fix them immediately although it's a free resource.

Feel free to let us know about what you want to see in the future downloads. We will definitely give it a thought while creating our next freebie.


CREDITS & REFERENCES

https://getbootstrap.com/

Stock Photos
https://unsplash.com/
https://www.freepik.com/
https://www.pexels.com/

Fonts
Google fonts
https://fonts.google.com/

Icons
https://icomoon.io/

JQuery Plugins
https://kenwheeler.github.io/slick/


Thanks for downloading from TemplatesJungle.com !

